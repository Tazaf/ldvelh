<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 16:55:51
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh2\application\View\templates\head_content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7225539327f7310c09-91761091%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '471975a53b0370b22691f91097c572091fd20635' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh2\\application\\View\\templates\\head_content.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7225539327f7310c09-91761091',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'titre' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_539327f7317763_68828689',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_539327f7317763_68828689')) {function content_539327f7317763_68828689($_smarty_tpl) {?><title>LDVELH - <?php echo (($tmp = @$_smarty_tpl->tpl_vars['titre']->value)===null||$tmp==='' ? "Accueil" : $tmp);?>
</title>
<meta charset="utf-8">
<link href="css/normalize.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/global.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/notification.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup.css" rel="stylesheet" type="text/css" media="all" />
<script src="js/jquery-2.0.3.min.js" type="text/javascript"></script>
<script src="js/global.js" type="text/javascript"></script>
<script src="js/notification.js" type="text/javascript"></script>
<script src="js/popup.js" type="text/javascript"></script><?php }} ?>
