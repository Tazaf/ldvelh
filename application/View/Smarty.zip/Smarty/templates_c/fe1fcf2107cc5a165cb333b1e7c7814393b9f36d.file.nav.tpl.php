<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 00:40:49
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh\application\View\templates\nav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14042539243716916b7-12579366%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fe1fcf2107cc5a165cb333b1e7c7814393b9f36d' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh\\application\\View\\templates\\nav.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14042539243716916b7-12579366',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'onglet' => 0,
    'personnage' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_539243716d5b42_91457747',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_539243716d5b42_91457747')) {function content_539243716d5b42_91457747($_smarty_tpl) {?>        <div id="small_title">
            <p><a href="index.php?controller=Personnage&action=showAll" title="Retour à la sélection du personnage"><span>LD<span>V</span>ELH</span></a> - Le Labyrinthe de la Mort</p>
        </div>
        <div id="dice_popup" class="popup_block">
            <h1>Lancer de dés</h1>
            <p>
                <label>Nombre (1~9) de D6 : </label>
                <input type="text" maxlength="1" placeholder="0" />
            </p>
            <button>Lancer</button>
            <h2>Résultats</h2>
            <div>
                <div>
                </div>
                <span>??</span>
                <div>Total</div>
            </div>
            <button>Quitter</button>
        </div>
        <nav>
            <ul class="centre">
                <li <?php if ($_smarty_tpl->tpl_vars['onglet']->value=='statut') {?>class="actif"<?php }?> title="Afficher le statut de <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['personnage']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
"><a href="index.php?controller=Personnage&action=showStatus&nom=<?php echo rawurlencode($_smarty_tpl->tpl_vars['personnage']->value->nom);?>
">Statut</a></li>
                <li <?php if ($_smarty_tpl->tpl_vars['onglet']->value=='sac') {?>class="actif"<?php }?> title="Afficher le contenu du sac de <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['personnage']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
"><a href="index.php?controller=SacADos&action=showBagContent&nom=<?php echo rawurlencode($_smarty_tpl->tpl_vars['personnage']->value->nom);?>
">Sac</a></li>
                <li <?php if ($_smarty_tpl->tpl_vars['onglet']->value=='combat') {?>class="actif"<?php }?> title="Afficher les combats de <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['personnage']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
"><a href="index.php?controller=Combat&action=showCombatLog&nom=<?php echo rawurlencode($_smarty_tpl->tpl_vars['personnage']->value->nom);?>
">Combat</a></li>
                <li id="dice" class="tooltip_right" title="Effectuer un ou des lancers de D6">Dés</li>
            </ul>
        </nav>
        <div class="centre">
            <h2><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['personnage']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
</h2>
            <?php if ($_smarty_tpl->tpl_vars['onglet']->value!='statut') {?>
            <div id="fast_stat">
                <div id="habilete"><span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->habilete;?>
</span><span class="max"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->habileteMax;?>
</span></div>
                <div id="endurance"><span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->endurance;?>
</span><span class="max"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->enduranceMax;?>
</span></div>
                <div id="chance"><span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->chance;?>
</span><span class="max"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->chanceMax;?>
</span></div>
            </div>
            <?php }?>
        </div><?php }} ?>
