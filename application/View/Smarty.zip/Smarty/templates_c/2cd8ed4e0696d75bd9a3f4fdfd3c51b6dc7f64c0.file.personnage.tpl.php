<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 00:40:27
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh\application\View\templates\personnage.tpl" */ ?>
<?php /*%%SmartyHeaderCode:303685392435b3ee325-99400507%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2cd8ed4e0696d75bd9a3f4fdfd3c51b6dc7f64c0' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh\\application\\View\\templates\\personnage.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '303685392435b3ee325-99400507',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head_content' => 0,
    'lang' => 0,
    'perso_vivants' => 0,
    'position' => 0,
    'perso_vivant' => 0,
    'perso_morts' => 0,
    'perso_mort' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5392435b4e7526_46035897',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5392435b4e7526_46035897')) {function content_5392435b4e7526_46035897($_smarty_tpl) {?><?php $_smarty_tpl->tpl_vars['head_content'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('head_content.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['footer'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <?php echo $_smarty_tpl->tpl_vars['head_content']->value;?>

        <link href="css/personnage.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/personnage.js" type="text/javascript"></script>
    </head>
    <body>
        <div id="big_title">
            <p>un livre</p>
            <p>dont <span>vous</span> &ecirc;tes</p>
            <p>le h&eacute;ros</p>
        </div>
        <h3 class="centre">d&eacute;fis fantastiques /5</h3>
        <h2 class="centre">Le Labyrinthe de la Mort</h2>
        <ul id="personnages" class="centre">
            <li id="new" tabindex="1"><span>+</span><?php echo $_smarty_tpl->tpl_vars['lang']->value['gen_new_char'];?>
</li>
            <?php  $_smarty_tpl->tpl_vars['perso_vivant'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['perso_vivant']->_loop = false;
 $_smarty_tpl->tpl_vars['position'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['perso_vivants']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['perso_vivant']->key => $_smarty_tpl->tpl_vars['perso_vivant']->value) {
$_smarty_tpl->tpl_vars['perso_vivant']->_loop = true;
 $_smarty_tpl->tpl_vars['position']->value = $_smarty_tpl->tpl_vars['perso_vivant']->key;
?>
                <li tabindex="<?php echo $_smarty_tpl->tpl_vars['position']->value+2;?>
">
                    <div class="nom"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['perso_vivant']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
<span class="tooltip_right" title="<?php echo $_smarty_tpl->tpl_vars['lang']->value['delete'];?>
 <?php echo (($tmp = @$_smarty_tpl->tpl_vars['perso_vivant']->value->nom)===null||$tmp==='' ? "le personnage" : $tmp);?>
"><?php echo $_smarty_tpl->tpl_vars['lang']->value['delete'];?>
</span></div>
                    <div class="stats">
                        <div title="<?php echo $_smarty_tpl->tpl_vars['lang']->value['dexterity'];?>
/<?php echo $_smarty_tpl->tpl_vars['lang']->value['dexterity'];?>
 Maximum">
                            <span><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->habilete;?>
</span>/<span class="max"><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->habileteMax;?>
</span>
                            <div><?php echo $_smarty_tpl->tpl_vars['lang']->value['dexterity'];?>
</div>
                        </div>
                        <div title="<?php echo $_smarty_tpl->tpl_vars['lang']->value['toughness'];?>
/<?php echo $_smarty_tpl->tpl_vars['lang']->value['toughness'];?>
 Maximum">
                            <span><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->endurance;?>
</span>/<span class="max"><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->enduranceMax;?>
</span>
                            <div><?php echo $_smarty_tpl->tpl_vars['lang']->value['toughness'];?>
</div>
                        </div>
                        <div title="<?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
/<?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
 Maximum">
                            <span><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->chance;?>
</span>/<span class="max"><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->chanceMax;?>
</span>
                            <div><?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
</div>
                        </div>
                    </div>
                    <a href="index.php?controller=Personnage&action=showStatus&nom=<?php echo rawurlencode($_smarty_tpl->tpl_vars['perso_vivant']->value->nom);?>
" title="Continuer l'aventure avec <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['perso_vivant']->value->nom;?>
<?php $_tmp1=ob_get_clean();?><?php echo (($tmp = @$_tmp1)===null||$tmp==='' ? "ce personnage" : $tmp);?>
" tabindex="-1" class="tooltip_right">À l'aventure !</a>
                </li>
            <?php } ?>
            <?php if (count($_smarty_tpl->tpl_vars['perso_vivants']->value)==0) {?>
                <li id="no_perso"><?php echo $_smarty_tpl->tpl_vars['lang']->value['no_living_hero'];?>
</li>
            <?php }?>
        </ul>
        <p class="centre"><?php echo $_smarty_tpl->tpl_vars['lang']->value['cemetery'];?>
</p>
        <ul id="perso_mort" class="centre">
            <?php  $_smarty_tpl->tpl_vars['perso_mort'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['perso_mort']->_loop = false;
 $_smarty_tpl->tpl_vars['position'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['perso_morts']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['perso_mort']->key => $_smarty_tpl->tpl_vars['perso_mort']->value) {
$_smarty_tpl->tpl_vars['perso_mort']->_loop = true;
 $_smarty_tpl->tpl_vars['position']->value = $_smarty_tpl->tpl_vars['perso_mort']->key;
?>
            <li tabindex="<?php echo $_smarty_tpl->tpl_vars['position']->value+2;?>
">
                <div class="nom"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['perso_mort']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
<span class="tooltip_right" title="Oublier <?php echo (($tmp = @$_smarty_tpl->tpl_vars['perso_mort']->value->nom)===null||$tmp==='' ? "le personnage" : $tmp);?>
"><?php echo $_smarty_tpl->tpl_vars['lang']->value['delete'];?>
</span></div>
                <div class="stats">
                    <div title="Habileté au moment de la mort">
                        <span><?php echo $_smarty_tpl->tpl_vars['perso_mort']->value->habilete;?>
</span>/<span class="max"><?php echo $_smarty_tpl->tpl_vars['perso_mort']->value->habileteMax;?>
</span>
                        <div><?php echo $_smarty_tpl->tpl_vars['lang']->value['dexterity'];?>
</div>
                    </div>
                    <div title="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['perso_mort']->value->nom)===null||$tmp==='' ? "Ce personnage" : $tmp);?>
 n'a plus d'endurance">
                        <span>Mort</span>
                        <div><?php echo $_smarty_tpl->tpl_vars['lang']->value['toughness'];?>
</div>
                    </div>
                    <div title="Chance au moment de la mort">
                        <span><?php echo $_smarty_tpl->tpl_vars['perso_mort']->value->chance;?>
</span>/<span class="max"><?php echo $_smarty_tpl->tpl_vars['perso_mort']->value->chanceMax;?>
</span>
                        <div><?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
</div>
                    </div>
                </div>
                <a href="index.php?controller=Personnage&action=showStatus&nom=<?php echo rawurlencode($_smarty_tpl->tpl_vars['perso_mort']->value->nom);?>
" title="Consulter l'état de <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['perso_mort']->value->nom;?>
<?php $_tmp2=ob_get_clean();?><?php echo (($tmp = @$_tmp2)===null||$tmp==='' ? "ce personnage" : $tmp);?>
 à sa mort" tabindex="-1" class="tooltip_right"><?php echo $_smarty_tpl->tpl_vars['lang']->value['condition'];?>
</a>
            </li>
            <?php } ?>
            <?php if (count($_smarty_tpl->tpl_vars['perso_morts']->value)==0) {?>
                <li id="no_perso"><?php echo $_smarty_tpl->tpl_vars['lang']->value['empty_cemetery'];?>
</li>
            <?php }?>
        </ul>
        <div class="popup_block" id="new_popup">
            <h1><?php echo $_smarty_tpl->tpl_vars['lang']->value['new_character'];?>
</h1>
            <p title="<?php echo $_smarty_tpl->tpl_vars['lang']->value['dexterity'];?>
 : 1d6 + 6, <?php echo $_smarty_tpl->tpl_vars['lang']->value['toughness'];?>
 : 2d6 + 12, <?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
 : 1d6 +6"><?php echo $_smarty_tpl->tpl_vars['lang']->value['random_stat_msg'];?>
</p>
            <form action="index.php" method="get">
                <h2><?php echo $_smarty_tpl->tpl_vars['lang']->value['name_hero'];?>
</h2>
                <input title="Insensible à la casse et aux accents" type="text" name="nom" placeholder="Nom" required tabindex="<?php echo count($_smarty_tpl->tpl_vars['perso_vivants']->value)+2;?>
" />
                <h2><?php echo $_smarty_tpl->tpl_vars['lang']->value['choose_potion'];?>
 <span>(ira dans le Sac)</span></h2>
                <div class="potions selected" tabindex="<?php echo count($_smarty_tpl->tpl_vars['perso_vivants']->value)+3;?>
">
                    <input type="radio" name="potion" value="1" checked="checked" />
                    <img src="./css/img/potionH.png" alt="Potion d'Adresse" />
                    <div>
                        <h3><?php echo $_smarty_tpl->tpl_vars['lang']->value['skill_potion'];?>
 (x2)</h3>
                        <ul>
                            <li><?php echo $_smarty_tpl->tpl_vars['lang']->value['refill'];?>
 <span class="habilete"><?php echo $_smarty_tpl->tpl_vars['lang']->value['dexterity'];?>
</span></li>
                            <li><?php echo $_smarty_tpl->tpl_vars['lang']->value['use_at_any_time'];?>
</li>
                        </ul>
                    </div>
                </div>
                <div class="potions" tabindex="<?php echo count($_smarty_tpl->tpl_vars['perso_vivants']->value)+4;?>
">
                    <input type="radio" name="potion" value="2" />
                    <img src="./css/img/potionE.png" alt="Potion d'Adresse" />
                    <div>
                        <h3><?php echo $_smarty_tpl->tpl_vars['lang']->value['stamina_potion'];?>
 (x2)</h3>
                        <ul>
                            <li><?php echo $_smarty_tpl->tpl_vars['lang']->value['refill'];?>
 <span class="endurance"><?php echo $_smarty_tpl->tpl_vars['lang']->value['toughness'];?>
</span></li>
                            <li><?php echo $_smarty_tpl->tpl_vars['lang']->value['use_at_any_time'];?>
</li>
                        </ul>
                    </div>
                </div>
                <div class="potions" tabindex="<?php echo count($_smarty_tpl->tpl_vars['perso_vivants']->value)+5;?>
">
                    <input type="radio" name="potion" value="3" />
                    <img src="./css/img/potionC.png" alt="Potion d'Adresse" />
                    <div>
                        <h3><?php echo $_smarty_tpl->tpl_vars['lang']->value['good_fortune'];?>
 (x2)</h3>
                        <ul>
                            <li><span>+ 1</span> <?php echo $_smarty_tpl->tpl_vars['lang']->value['to'];?>
 <span class="chance"><?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
 Max</span></li>
                            <li><?php echo $_smarty_tpl->tpl_vars['lang']->value['refill'];?>
 <span class="chance"><?php echo $_smarty_tpl->tpl_vars['lang']->value['chance'];?>
</span></li>
                            <li><?php echo $_smarty_tpl->tpl_vars['lang']->value['use_at_any_time'];?>
</li>
                        </ul>
                    </div>
                </div>
                <input type="hidden" value="Personnage" name="controller" />
                <input type="hidden" value="createNew" name="action" />
                <input type="hidden" value="2" name="quantite" />
                <input type="reset" value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['actually_no'];?>
" tabindex="<?php echo count($_smarty_tpl->tpl_vars['perso_vivants']->value)+7;?>
"/>
                <input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['lets_go'];?>
" tabindex="<?php echo count($_smarty_tpl->tpl_vars['perso_vivants']->value)+6;?>
"/>
            </form>
        </div>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
