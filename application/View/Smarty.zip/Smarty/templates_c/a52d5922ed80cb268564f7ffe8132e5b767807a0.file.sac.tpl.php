<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 00:41:35
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh\application\View\templates\sac.tpl" */ ?>
<?php /*%%SmartyHeaderCode:304755392439f64df08-61428200%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a52d5922ed80cb268564f7ffe8132e5b767807a0' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh\\application\\View\\templates\\sac.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '304755392439f64df08-61428200',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head_content' => 0,
    'barre_navigation' => 0,
    'personnage' => 0,
    'contenu' => 0,
    'emplacement' => 0,
    'effet' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5392439f71fbf9_29556666',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5392439f71fbf9_29556666')) {function content_5392439f71fbf9_29556666($_smarty_tpl) {?><?php $_smarty_tpl->tpl_vars['head_content'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('head_content.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['barre_navigation'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['footer'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <?php echo $_smarty_tpl->tpl_vars['head_content']->value;?>

        <!-- CSS et JS pour la barre de naviguation -->
        <link href="css/nav.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/nav.js" type="text/javascript"></script>
        <!-- CSS et JS pour la fiche de personnage -->
        <link href="css/sac.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/sac.js" type="text/javascript"></script>
    </head>
    <body>
        <?php echo $_smarty_tpl->tpl_vars['barre_navigation']->value;?>

        <div class="centre">
            <button id="equip">Ajouter un objet au sac</button>
            <form id="new_equip" action="index.php" method="get">
                <select name="possession_id">
                    <optgroup id="possession_potions" label="Potions">
                    </optgroup>
                    <optgroup id="possession_equip" label="Équipements">
                    </optgroup>
                    <optgroup id="possession_bijoux" label="Bijoux">
                    </optgroup>
                </select>
                <label class="tooltip_right" title="99 max." for="quantite">Quantité</label>
                <input class="tooltip_right" title="99 max." type="text" name="quantite" maxlength="2" value="1" required />
                <input type="hidden" name="controller" value="SacADos" />
                <input type="hidden" name="action" value="addPossession" />
                <input type="hidden" name="nom" value="<?php echo rawurlencode($_smarty_tpl->tpl_vars['personnage']->value->nom);?>
" />
                <input type="submit" value="Ajouter" />
                <input type="reset" value="Annuler" />
            </form>
            <h3>Potion(s)</h3>
            <?php  $_smarty_tpl->tpl_vars['emplacement'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['emplacement']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['contenu']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['emplacement']->key => $_smarty_tpl->tpl_vars['emplacement']->value) {
$_smarty_tpl->tpl_vars['emplacement']->_loop = true;
?>
                <?php if ($_smarty_tpl->tpl_vars['emplacement']->value['possession']->type=="potion") {?>
                    <div class="<?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->type;?>
">
                        <div class="nom" data-rel="<?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->id;?>
"><?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->nom;?>
<span class="quantite"><?php echo $_smarty_tpl->tpl_vars['emplacement']->value['quantite'];?>
</span></div>
                        <?php if (count($_smarty_tpl->tpl_vars['emplacement']->value['possession']->effets)>0) {?>
                            <ul>
                                <?php  $_smarty_tpl->tpl_vars['effet'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['effet']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['emplacement']->value['possession']->effets; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['effet']->key => $_smarty_tpl->tpl_vars['effet']->value) {
$_smarty_tpl->tpl_vars['effet']->_loop = true;
?>
                                    <?php if ($_smarty_tpl->tpl_vars['effet']->value->valeur==0) {?>
                                        <li>Rend tous les points de <span class="<?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
"><?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
</span></li>
                                    <?php } else { ?>
                                    <li><?php echo $_smarty_tpl->tpl_vars['effet']->value->modificateur;?>
 <?php echo $_smarty_tpl->tpl_vars['effet']->value->valeur;?>
 à <span class="<?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
"><?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
</span></li>
                                    <?php }?>
                                <?php } ?>
                            </ul>
                            <div class="use">Utiliser</div>
                        <?php } else { ?>
                            <ul>
                                <li>Aucun effet</li>
                            </ul>
                            <div class="remove">Retirer</div>
                        <?php }?>
                   </div>
                <?php }?>
            <?php } ?>
            <h3>Équipement(s)</h3>
            <?php  $_smarty_tpl->tpl_vars['emplacement'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['emplacement']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['contenu']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['emplacement']->key => $_smarty_tpl->tpl_vars['emplacement']->value) {
$_smarty_tpl->tpl_vars['emplacement']->_loop = true;
?>
                <?php if ($_smarty_tpl->tpl_vars['emplacement']->value['possession']->type=="equipement") {?>
                    <div class="<?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->type;?>
">
                        <div class="nom" data-rel="<?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->id;?>
"><?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->nom;?>
<span class="quantite"><?php echo $_smarty_tpl->tpl_vars['emplacement']->value['quantite'];?>
</span></div>
                        <ul>
                        <?php if (count($_smarty_tpl->tpl_vars['emplacement']->value['possession']->effets)>0) {?>
                            <?php  $_smarty_tpl->tpl_vars['effet'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['effet']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['emplacement']->value['possession']->effets; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['effet']->key => $_smarty_tpl->tpl_vars['effet']->value) {
$_smarty_tpl->tpl_vars['effet']->_loop = true;
?>
                                <?php if ($_smarty_tpl->tpl_vars['effet']->value->valeur==0) {?>
                                    <li>Rends tous les points de <span class="<?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
"><?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
</span></li>
                                <?php } else { ?>
                                <li><?php echo $_smarty_tpl->tpl_vars['effet']->value->modificateur;?>
 <?php echo $_smarty_tpl->tpl_vars['effet']->value->valeur;?>
 à <span class="<?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
"><?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
</span></li>
                                <?php }?>
                            <?php } ?>
                        <?php } else { ?>
                            <li>Aucun effet</li>
                        <?php }?>
                        </ul>
                        <div class="remove">Retirer</div>
                   </div>
                <?php }?>
            <?php } ?>
            <h3>Bijou(x)</h3>
            <?php  $_smarty_tpl->tpl_vars['emplacement'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['emplacement']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['contenu']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['emplacement']->key => $_smarty_tpl->tpl_vars['emplacement']->value) {
$_smarty_tpl->tpl_vars['emplacement']->_loop = true;
?>
                <?php if ($_smarty_tpl->tpl_vars['emplacement']->value['possession']->type=="bijoux") {?>
                    <div class="<?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->type;?>
">
                        <div class="nom" data-rel="<?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->id;?>
"><?php echo $_smarty_tpl->tpl_vars['emplacement']->value['possession']->nom;?>
<span class="quantite"><?php echo $_smarty_tpl->tpl_vars['emplacement']->value['quantite'];?>
</span></div>
                        <ul>
                        <?php if (count($_smarty_tpl->tpl_vars['emplacement']->value['possession']->effets)>0) {?>
                            <?php  $_smarty_tpl->tpl_vars['effet'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['effet']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['emplacement']->value['possession']->effets; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['effet']->key => $_smarty_tpl->tpl_vars['effet']->value) {
$_smarty_tpl->tpl_vars['effet']->_loop = true;
?>
                                <?php if ($_smarty_tpl->tpl_vars['effet']->value->valeur==0) {?>
                                    <li>Rends tous les points de <span class="<?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
"><?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
</span></li>
                                <?php } else { ?>
                                <li><?php echo $_smarty_tpl->tpl_vars['effet']->value->modificateur;?>
 <?php echo $_smarty_tpl->tpl_vars['effet']->value->valeur;?>
 à <span class="<?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
"><?php echo $_smarty_tpl->tpl_vars['effet']->value->caracteristique;?>
</span></li>
                                <?php }?>
                            <?php } ?>
                        <?php } else { ?>
                            <li>Aucun effet</li>
                        <?php }?>
                        </ul>
                        <div class="remove">Retirer</div>
                   </div>
                <?php }?>
            <?php } ?>
        </div>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
