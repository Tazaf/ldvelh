<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 00:40:27
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh\application\View\templates\head_content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:292735392435b4f59e4-96812942%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '35fde043727564b5882470239c01e92f9ed7100d' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh\\application\\View\\templates\\head_content.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '292735392435b4f59e4-96812942',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'titre' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5392435b4fca26_84346791',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5392435b4fca26_84346791')) {function content_5392435b4fca26_84346791($_smarty_tpl) {?><title>LDVELH - <?php echo (($tmp = @$_smarty_tpl->tpl_vars['titre']->value)===null||$tmp==='' ? "Accueil" : $tmp);?>
</title>
<meta charset="utf-8">
<link href="css/normalize.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/global.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/notification.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popup.css" rel="stylesheet" type="text/css" media="all" />
<script src="js/jquery-2.0.3.min.js" type="text/javascript"></script>
<script src="js/global.js" type="text/javascript"></script>
<script src="js/notification.js" type="text/javascript"></script>
<script src="js/popup.js" type="text/javascript"></script><?php }} ?>
