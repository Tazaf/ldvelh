<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 16:58:57
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh2\application\View\templates\combat.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29663539328b1eb1971-11698722%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b314d8047b3ac28f9127cb376066d13005b5abf1' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh2\\application\\View\\templates\\combat.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29663539328b1eb1971-11698722',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head_content' => 0,
    'barre_navigation' => 0,
    'paragraphes' => 0,
    'paragraphe' => 0,
    'combat_log' => 0,
    'personnage' => 0,
    'combat' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_539328b1f1f055_08247228',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_539328b1f1f055_08247228')) {function content_539328b1f1f055_08247228($_smarty_tpl) {?><?php $_smarty_tpl->tpl_vars['head_content'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('head_content.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['barre_navigation'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['footer'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <?php echo $_smarty_tpl->tpl_vars['head_content']->value;?>

        <!-- CSS et JS pour la barre de naviguation -->
        <link href="css/nav.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/nav.js" type="text/javascript"></script>
        <!-- CSS et JS pour la fiche de personnage -->
        <link href="css/combat.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/combat.js" type="text/javascript"></script>
    </head>
    <body>
        <?php echo $_smarty_tpl->tpl_vars['barre_navigation']->value;?>

        <div class="centre">
            <div id="select_battle">
                <label for="paragraphes">Paragraphe n° </label>
                <select name="paragraphe">
                    <?php  $_smarty_tpl->tpl_vars['paragraphe'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['paragraphe']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['paragraphes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['paragraphe']->key => $_smarty_tpl->tpl_vars['paragraphe']->value) {
$_smarty_tpl->tpl_vars['paragraphe']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['paragraphe']->value['numero'];?>
"><?php echo $_smarty_tpl->tpl_vars['paragraphe']->value['numero'];?>
</option>
                    <?php } ?>
                </select>
                <button>Démarrer le combat</button>
            </div>
            <div id="combat"></div>
            <div id="combat_log">
                <?php if (count($_smarty_tpl->tpl_vars['combat_log']->value)=="0") {?>
                <div id="no_combat"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['personnage']->value->nom, ENT_QUOTES, 'UTF-8', true);?>
 n'a pas encore combattu.</div>
                <?php }?>
                <?php  $_smarty_tpl->tpl_vars['combat'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['combat']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['combat_log']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['combat']->key => $_smarty_tpl->tpl_vars['combat']->value) {
$_smarty_tpl->tpl_vars['combat']->_loop = true;
?>
                <div>
                    <?php if ($_smarty_tpl->tpl_vars['combat']->value['victoire']=="1") {?>
                    <p class="victoire">Victoire !</p>
                    <p>A vaincu <span class="monstre_nom"><?php echo $_smarty_tpl->tpl_vars['combat']->value['nom'];?>
</span> <span class="habilete"><?php echo $_smarty_tpl->tpl_vars['combat']->value['habilete'];?>
</span><span class="endurance"><?php echo $_smarty_tpl->tpl_vars['combat']->value['endurance'];?>
</span> au paragraphe <?php echo $_smarty_tpl->tpl_vars['combat']->value['paragraphe_numero'];?>
</p>
                    <?php } else { ?>
                    <p class="defaite">Défaite...</p>
                    <p>A été vaincu par <span class="monstre_nom"><?php echo $_smarty_tpl->tpl_vars['combat']->value['nom'];?>
</span> <span class="habilete"><?php echo $_smarty_tpl->tpl_vars['combat']->value['habilete'];?>
</span><span class="endurance"><?php echo $_smarty_tpl->tpl_vars['combat']->value['endurance'];?>
</span> au paragraphe <?php echo $_smarty_tpl->tpl_vars['combat']->value['paragraphe_numero'];?>
</p>
                    <?php }?>
                </div>
                <?php } ?>
            </div>
        </div>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
