<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 00:40:27
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh\application\View\templates\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:322865392435b50a442-57949484%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '126ebe4fa85bc650a877316f34d8277e16a62216' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh\\application\\View\\templates\\footer.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '322865392435b50a442-57949484',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5392435b50c047_78969497',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5392435b50c047_78969497')) {function content_5392435b50c047_78969497($_smarty_tpl) {?>        <footer class="centre">
            <p>LDVELH v.1.1 - Création : Mathias Oberson - Février 2014</p>
        </footer>
    </body>
</html><?php }} ?>
