<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 16:58:29
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh2\application\View\templates\statut.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2910753932895a7d063-05225504%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '55ad333137944db883e01d82c08c5365be19a73b' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh2\\application\\View\\templates\\statut.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2910753932895a7d063-05225504',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head_content' => 0,
    'barre_navigation' => 0,
    'personnage' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_53932895ac76a1_59735514',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53932895ac76a1_59735514')) {function content_53932895ac76a1_59735514($_smarty_tpl) {?><?php $_smarty_tpl->tpl_vars['head_content'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('head_content.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['barre_navigation'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<?php $_smarty_tpl->tpl_vars['footer'] = new Smarty_variable($_smarty_tpl->getSubTemplate ('footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0));?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <?php echo $_smarty_tpl->tpl_vars['head_content']->value;?>

        <!-- CSS et JS pour la barre de naviguation -->
        <link href="css/nav.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/nav.js" type="text/javascript"></script>
        <!-- CSS et JS pour la fiche de personnage -->
        <link href="css/statut.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/statut.js" type="text/javascript"></script>
    </head>
    <body>
        <?php echo $_smarty_tpl->tpl_vars['barre_navigation']->value;?>

        <div class="centre">
            <button disabled="disabled" class="status_action">Annuler</button>
            <button disabled="disabled" class="status_action">Sauver</button>
            <h3>Caractéristiques</h3>
            <div class="stats">
                <span>Habileté</span>
                <button>- 1</button>
                <span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->habilete;?>
</span>
                <span class="max"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->habileteMax;?>
</span>
                <button>+ 1</button>
            </div>
            <div class="stats">
                <span>Endurance</span>
                <button>- 1</button>
                <span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->endurance;?>
</span>
                <span class="max"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->enduranceMax;?>
</span>
                <button>+ 1</button>
            </div>
            <div class="stats">
                <span>Chance</span>
                <button>- 1</button>
                <span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->chance;?>
</span>
                <span class="max"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->chanceMax;?>
</span>
                <button>+ 1</button>
            </div>
            <h3>Provisions</h3>
            <div>
                <span>Repas</span>
                <button>- 1</button>
                <span class="actuel"><?php echo $_smarty_tpl->tpl_vars['personnage']->value->repas;?>
</span>
                <button>+ 1</button>
            </div>
            <h3>Bourse</h3>
            <div>
                <span>Pièce(s) d'or</span>
                <input type="text" name="bourse" value="<?php echo $_smarty_tpl->tpl_vars['personnage']->value->bourse;?>
" class="actuel tooltip_right" maxlength="9" title="Flèche haute : +1 | Flèche basse : -1"/>
            </div>
        </div>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
