<?php /* Smarty version Smarty-3.1.16, created on 2014-06-07 16:55:51
         compiled from "E:\Dropbox\NetBeansProjects\PHP\ldvelh2\application\View\templates\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4734539327f731fc96-61166753%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '493ee7812706d64635cc6c2a141a6bc210b61ee4' => 
    array (
      0 => 'E:\\Dropbox\\NetBeansProjects\\PHP\\ldvelh2\\application\\View\\templates\\footer.tpl',
      1 => 1396636857,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4734539327f731fc96-61166753',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_539327f73218b0_58443456',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_539327f73218b0_58443456')) {function content_539327f73218b0_58443456($_smarty_tpl) {?>        <footer class="centre">
            <p>LDVELH v.1.1 - Création : Mathias Oberson - Février 2014</p>
        </footer>
    </body>
</html><?php }} ?>
