<?php

class EffetPossession extends Eloquent {

	protected $table = 'effet_possession';
	public $timestamps = false;

}