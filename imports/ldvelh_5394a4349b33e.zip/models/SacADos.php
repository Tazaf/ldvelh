<?php

class SacADos extends Eloquent {

	protected $table = 'sac_a_dos';
	public $timestamps = false;

}