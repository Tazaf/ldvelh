# ldvelh

#### versions

[v1.0](http://github.com/Tazaf/ldvelh/tree/v1.0)

## Français

### Résumé

Ce projet a pour but d'aider les joueurs de LDVELH (Livre Dont Vous Êtes Le Héros) à gérer leur personnage. Actuellement, seul un LDVELH est supporté : le Labyrinthe de la Mort par Ian Livingstone.
Il a été mise sur pied comme projet d'école pour un cours de PHP. À cause du temps limité à disposition et des connaissances à lacunaires de l'époque, il est relativement limité à l'heure actuelle et ne permet pas d'ajouter facilement la gestion de nouveaux livres, encore moins de nouvelles règles de jeu. De plus, le but de ce projet d'école était de nous faire développer une application depuis la base sans aucune aide de framework ou de plug-ins.

## English

### Summary

This project is an attempt to help players of adventure gamebooks books in managing their character. Right now, only one book is supported : Deathtrap Dungeon by Ian Livingstone.
It was created as a school project for a PHP course. Because of the limited time available and the then incomplete knowledge of PHP and the MVC pattern, it's quite limited as for now and can not be easily expand in supporting other books, let alone other game rules. Therefore, the purpose of the course was to develop an application from scratch without any framework or plug-ins.
